  //Impostazioni Swiper
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: 1,
            loop: true,
            freeMode: true,
            loopAdditionalSlides:5,
            speed: 500,
            autoplay: {
            delay: 4000,
            },
            pagination: {
            el: ".swiper-pagination",
            clickable: true,
            },
            navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
            },
            breakpoints:{
              640: {
                slidesPerView: 2,
                spaceBetween: 5
              },

              800: {
                slidesPerView: 3,
                spaceBetween: 5
              },

              1300:{
                slidesPerView: 4,
                spaceBetween: 10
              },

              1920:{
                slidesPerView: 6,
                spaceBetween: 10
              },

            }
        });