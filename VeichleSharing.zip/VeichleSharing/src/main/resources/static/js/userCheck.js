
function hideFunction() {

    var x = document.getElementById('contactForm');
    var y = document.getElementById('thankyou');
    if(x.style.display === 'none'){
        x.style.display = 'block';
        y.style.display = 'none';
    } else {
        x.style.display = 'none';
        y.style.display = 'block';
        setInterval(function() {
            var div = document.getElementById("counter2");
            var count = div.textContent * 1 - 1;
            div.textContent = count;
            if (count <= 0) {
                window.location.replace("contatti");
            }
        }, 1000);       
    }
}

let btnContact = document.getElementById('btnContact');
btnContact.addEventListener('click', hideFunction, false);