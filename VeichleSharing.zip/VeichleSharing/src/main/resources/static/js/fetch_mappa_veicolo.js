var datiPos=[];

$.ajax({
    url: "/api/veicoli",
    type: "GET",
    dataType: "json",
    success: function(veicoli){
        for (let i = 0; i < veicoli.length; i++){
            var id = veicoli[i].id; //da vedere se da usare
            var posizione = veicoli[i].posizione;
            var descrizione=veicoli[i].descrizione;
			
        }
	console.log(veicoli);
        function contructor (id, posizione, descrizione){
			this.id = id;
            this.posizione=posizione;
            this.descrizione=descrizione;
        }

        var posMap = new contructor(id, posizione, descrizione);

        datiPos.push(posMap);
        var query_addr = datiPos[0].posizione;
		console.log(datiPos);

        const provider = new window.GeoSearch.OpenStreetMapProvider();
        var query_promise = provider.search({
            query: query_addr
        });
		console.log(query_promise);
		console.log(query_addr);

        query_promise.then(value=>{	
	            for (i=0; i<1;i++){
	                var x_coor = value[i].x;
	                var y_coor = value[i].y;
	                var label = value[i].label;
	                var marker = L.marker([y_coor, x_coor]).addTo(map);
	                marker.bindPopup("<b>"+datiPos[i].descrizione+"</b><br>" + label).popup;
	            };
        }, reason =>{
            console.log (reason);
        })
    }
})


//creazione mappa e inserimento tiles
var map = L.map("map").setView([45.07, 7.66],12);

const attribution="&copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors";
const tileUrl="http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
const tiles=L.tileLayer(tileUrl, {attribution});
tiles.addTo(map);