var map = L.map('map').setView([45.0703, 7.6869], 13);
L.tileLayer('https://api.mapbox.com/styles/v1/tudorlex/cky32s38ablsm14quycrxzxhj/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoidHVkb3JsZXgiLCJhIjoiY2t5MzJpNnp6MHI5czJ3bXJuMjMxb3FnayJ9.Bq4EA-B_YKxxsPuokUvMEw', {  
attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>', 
maxZoom: 15,
id: 'mapbox/streets-v11',
tileSize: 512,
zoomOffset: -1,
}).addTo(map);
var marker = L.marker([45.066210, 7.681522]).addTo(map);
                    