var prevScrollpos = window.pageYOffset;
           
window.onscroll = function() {

    var currentScrollPos = window.pageYOffset;

    if (prevScrollpos > currentScrollPos) {
                
        document.getElementById("nv").style.top = "0";
    } else {
        document.getElementById("nv").style.top = "-50px";
        }
    prevScrollpos = currentScrollPos;
}

const nav = document.getElementById('nv');
let navTop = nv.offsetTop;

function fixedNav() {
    if (window.scrollY > navTop) {
        nav.classList.add('scrolled');
    }
    else {
        nav.classList.remove('scrolled');
    }
}

window.addEventListener('scroll', fixedNav, false);