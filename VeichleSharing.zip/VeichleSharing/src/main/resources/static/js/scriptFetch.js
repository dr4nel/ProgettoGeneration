$('#pills-home-tab').on('click', function(){
    $('#pills-home-tab').addClass('selected');
    $('#pills-profile-tab').removeClass('selected');
});

$('#pills-profile-tab').on('click', function(){
    $('#pills-profile-tab').addClass('selected');
    $('#pills-home-tab').removeClass('selected');
});

var datiOBJ = [];

$.ajax({
    url: "/api/veicoli",
        type: 'GET',
        dataType: 'json',
        success: function(veicoli){

            let elem = ''; 
            let elem2 = ''; 
            let elem3 = '';
            let elem4 = '';
			let elem5 = '';
            let elemA = '';
            let elemB = ''; 
            let elemC = '';

            let el = '';
	
            
            for(let i = 0; i<veicoli.length; i++){

            var id = veicoli[i].id;
            var tipologia = veicoli[i].tipologia;
            var descrizione = veicoli[i].descrizione;
            var posizione = veicoli[i].posizione;
            var disponibilita = veicoli[i].disponibilita;
			var name_img = veicoli[i].nameImg;
			var url = veicoli[i].url;

            if(disponibilita === true){

            function constructor(id, tipologia, descrizione, posizione, name_img, url){
                this.id = id;
                this.tipologia = tipologia;
                this.descrizione = descrizione;
                this.posizione = posizione;
				this.name_img = name_img;
				this.url = url;
            }

            var veicolo = new constructor(id, tipologia, descrizione, posizione, name_img, url);

            datiOBJ.push(veicolo);
            
            elem += `<div>${tipologia}</div>`;
            elem2 += `<div>${descrizione}</div>`;
            elem3 += `<div>${posizione}</div>`;
            elem4 += `<div><a href="vista-veicolo/${id}" id="btnCheck"><i class="fas fa-external-link-square-alt btnPrenota"></i></a></div>`;
			
			console.log(veicolo);
            el += `<div class="swiper-slide hello"><img src="${url}" class="imageC"><div class="middle"><a class="carousel" href="vista-veicolo/${id}">${descrizione} - ${posizione}</a></div></div>`;

            } else{
                function constructor(id, tipologia, descrizione, posizione){
                    this.id = id;
                    this.tipologia = tipologia;
                    this.descrizione = descrizione;
                    this.posizione = posizione;
                }
    
                var veicolo = new constructor(id, tipologia, descrizione, posizione);
    
                datiOBJ.push(veicolo);
                
                elemA += `<div>${tipologia}</div>`;
                elemB += `<div>${descrizione}</div>`;
                elemC += `<div>${posizione}</div>`;
                
                }
            }

            var veicoli = JSON.stringify(datiOBJ);

        $('#swiperFetch').html(el);
        $('#disp').html(elem);
        $('#disp2').html(elem2);
        $('#disp3').html(elem3);
        $('#pulsantePrenota').html(elem4);
        $('#noDisp').html(elemA);
        $('#noDisp2').html(elemB);
        $('#noDisp3').html(elemC);
        },

        fail: function(){
            console.log('Connection failed');
        }
});

