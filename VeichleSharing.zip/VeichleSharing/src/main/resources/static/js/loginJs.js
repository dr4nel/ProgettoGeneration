const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

const btnSignUp = document.getElementById('btnSignUp');
const btnSignIn = document.getElementById('btnSignIn');

const username = document.getElementById('username');
const email = document.getElementById('email');
const password = document.getElementById('password');
const password2 = document.getElementById('password2');

let usernameErr = document.getElementById('usernameErr');
let emailErr = document.getElementById('emailErr');
let passwordErr = document.getElementById('passwordErr');
let password2Err = document.getElementById('password2Err')

var emailformat = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
var passwordformat = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;

//cambio finestra accedi/registra e cancella dati inseriti
signUpButton.addEventListener('click', () => {
	container.classList.add("right-panel-active");
	document.getElementById('passwordSignIn').value = '';
	document.getElementById('usernameSignIn').value = '';
});

signInButton.addEventListener('click', () => {
	container.classList.remove("right-panel-active");
	document.getElementById('username').value ='';
	document.getElementById('email').value ='';
	document.getElementById('password').value ='';
	document.getElementById('password2').value ='';
});

//controllo campi input
btnSignUp.addEventListener('click', e => {	
	checkInputs();
	e.preventDefault();
});

function checkInputs() {

	var avviso ='';

	if(username.value.trim().length < 3) {
		avviso = "Lo username deve contenere almeno 3 caratteri";
		usernameErr.innerHTML = avviso;
	} else {
		usernameErr.innerHTML = '';
	}
	
	if(email.value.trim() === '' || !email.value.match(emailformat)){
		avviso = "Ricontrolla la mail inserita";
		emailErr.innerHTML = avviso;
	} else {
		emailErr.innerHTML ='';
	}
	
	
	if (password.value.trim() === '' || !password.value.match(passwordformat)){
		avviso = "La password dev'essere lunga almeno 8 caratteri e deve contenere: almeno una lettera miuscola, una minuscola, un numero e un carattere speciale tra # ? ! @ $ % ^ & * - ";
		passwordErr.innerHTML = avviso;
	} else {
		passwordErr.innerHTML = '';
	}
	
	
	if (password.value.trim() !== password2.value.trim()) {
		avviso = "Le due password non coincidono";
		password2Err.innerHTML = avviso;
	} else {
		password2Err.innerHTML = '';
	}

}

//password visibility
function toggleSignUp() {
	
	let y = document.getElementById('hide1');
	let z = document.getElementById('hide2');

	if (password.type==='password'){
		password2.type = 'text';
		password.type ='text';
		y.style.display = "block";
		z.style.display = "none";
	} else {
		password.type = 'password';
		password2.type = 'password'
		y.style.display = "none";
		z.style.display = "block";
	}
}

function toggleSignIn() {

	let passwordSignIn = document.getElementById('passwordSignIn');
	let a = document.getElementById('hideA');
	let b = document.getElementById('hideB');

	if (passwordSignIn.type==='password'){
		passwordSignIn.type ='text';
		a.style.display = "block";
		b.style.display = "none";
	} else {
		passwordSignIn.type = 'password';
		a.style.display = "none";
		b.style.display = "block";
	}
}

//salva credenziali 
/*
function salvaCredenziali() {

	let passwordSignIn = document.getElementById('passwordSignIn');
	let usernameSignIn = document.getElementById('usernameSignIn');

	localStorage.setItem('username', usernameSignIn.value);
	localStorage.setItem('password', passwordSignIn.value);
}

btnSignIn.addEventListener('click', salvaCredenziali, false);*/