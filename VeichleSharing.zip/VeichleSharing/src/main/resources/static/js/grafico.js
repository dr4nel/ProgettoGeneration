var nBiciclette = 0;
var nAutoElettriche = 0;
var nAutoIbride = 0;
var nMonopattini = 0;
var nScooterElettr = 0;

var datiGrafico = [];
    
$.ajax({
    url: "/api/veicoli",
    type: 'GET',
    dataType: 'json',
    success: function (veicoli) {

        for (let i = 0; i < veicoli.length; i++) {

            var id = veicoli[i].id;
            var tipologia = veicoli[i].tipologia;
            var alimentazione = veicoli[i].alimentazione;

            function constructor(id, tipologia, alimentazione){
                this.id = id;
                this.tipologia = tipologia;
                this.alimentazione = alimentazione;
            }

            var veicolo = new constructor(id, tipologia, alimentazione);

            datiGrafico.push(veicolo);

            if(tipologia == "automobile" && alimentazione == "elettrica") {
                nAutoElettriche += 1;
             } else if (tipologia == "automobile" && alimentazione == "ibrida") {
                nAutoIbride += 1;
             } else if (tipologia == "scooter" && alimentazione == "elettrica") {
                nScooterElettr += 1;
             } else if (tipologia == "bicicletta") {
                nBiciclette += 1;
             } else if (tipologia == "monopattino") {
                nMonopattini += 1;
             } 
        }

        var co2Bici=1*nBiciclette;
        var co2AutoEle=0.6*nAutoElettriche;
        var co2AutoIb=0.4*nAutoIbride;
        var co2Monop=0.95*nMonopattini;
        var co2ScotElet=0.6*nScooterElettr;
                    
                      
        let myChart = document.getElementById("myChart");
        let co2Chart=new Chart(myChart,{
            type:"doughnut",         
            data:{
                labels:["Biciclette", "Auto Elettriche", "Auto Ibride", "Monopattino","Scooter Elettrico"],
                datasets:[{
                   
                    data:[
                        co2Bici,
                        co2AutoEle,
                        co2AutoIb,
                        co2Monop,
                        co2ScotElet   
                        ],
        
                    backgroundColor:[
                        "rgb(73, 255, 0)",
                        "rgb(251, 255, 0)",
                        "rgb(255, 147, 0)",
                        "rgb(62, 219, 240)",
                        "rgb(255, 0, 0)"  
                        ],
                    borderColor:[
                        "rgb(255,255,255)",
                        "rgb(255,255,255)",
                        "rgb(255,255,255)",
                        "rgb(255,255,255)",
                        "rgb(255,255,255)"
                        ],
                    borderWidth: 3,
                    hoverBorderColor: "rgb(255,255,255)",
                    hoverOffset: 20
                        }]
            },
            options:{
                responsive: true,
                maintainAspectRatio: true,
                                    
                plugins:{
                    legend:{
                        position: 'top'
                    }
                }
            },
        });


    }
})

