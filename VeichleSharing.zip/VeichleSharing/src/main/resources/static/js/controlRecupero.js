// LOGICA CODICE DI SICUREZZA ------------------------------------------------------------------------------
function CAPTCHA() {
    var car, min, max, dif, lun, inc;
    car = "abcdefghijklmnopqrstuvwxyz";
    car += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    car += "1234567890";
    min = 5;
    max = 5;
    dif = max - min;
    lun = Math.round((Math.random() * dif) + min);
    inc = 0;
    cod = "";
    while (inc < lun) {
        cod += car.charAt(Math.round(Math.random() * car.length));
        inc++;
    }
    return cod;
}
document.getElementById("captcha").innerText = CAPTCHA();


// CONTROLLI PRIMA DELL'INVIO -----------------------------------------------------------------------------------
function Invia() {
    var email = document.getElementById('testo').value;
    var codice = document.getElementById('codice').value;

    var emailformat = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

    if (email === "" || !email.match(emailformat)) {
        alert("Controlla il campo email");
        document.getElementById("captcha").innerText = CAPTCHA();
    } else if (codice === "") {
        alert("Inserisci il codice di sicurezza");
        document.getElementById("captcha").innerText = CAPTCHA();
    } else if (codice != document.getElementById("captcha").innerText) {
        alert("Il codice di sicurezza è errato!");
        document.getElementById("captcha").innerText = CAPTCHA();
    } else {
        document.modulo.submit();
    }
    $('#testo').val('');
    $('#codice').val('');
}