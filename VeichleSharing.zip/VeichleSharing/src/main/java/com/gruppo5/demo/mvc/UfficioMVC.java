package com.gruppo5.demo.mvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.gruppo5.demo.entities.Utente;
import com.gruppo5.demo.services.UtenteService;

@Controller
@RequestMapping("/lista-utenti")
@SessionAttributes("utente")
public class UfficioMVC {
	
	@Autowired
	UtenteService us;
	
	//tutti gli utenti
	@GetMapping //rotta /lista-utenti
	public String findAll(Model model) {
		
		model.addAttribute("findAll", us.findAll());
		
		return "lista-utenti";
	}
	
	//Aggiorno un utente
	@GetMapping("/{id}") //rotta /lista-utenti/{id}
	public String updForm(@PathVariable("id") int id, Model model) {
		//cerco l'utente da modificare
		Utente user = us.getUtenteById(id);
			
		//controllo se esiste
		if(user == null)
			return "redirect:/lista-utenti";
			
		//lo aggiungo al model
		model.addAttribute("user", user);
			
		return "utente-form";
	}
		
	//Salvo il nuovo utente
	@PostMapping("/save")
	public String saveUtente(Utente u) {
		//salvo l'utente
		us.saveOne(u);
				
		//mi riporta alla pagine iniziale
		return "redirect:/lista-utenti";
	}
	
	//Creo un nuovo utente
	@GetMapping("/addform")
	public String addForm(Model model) {
		//aggiugno un utente vuoto
		//lo collego ai campi del form
		model.addAttribute("user", new Utente());
			
		return "/utente-form";
	}
	
	//Cancello un utente
	@GetMapping("/delete/{id}")
	public String delUtente(@PathVariable("id") int id) {
			
		//cerco l'utente
		Utente user = us.getUtenteById(id);
			
		//controllo l'id
		if(user == null)
			return "redirect:/lista-utenti";
			
		//cancello l'utente
		us.deleteUtenteById(id);
			
		return "redirect:/lista-utenti";
	}
}
