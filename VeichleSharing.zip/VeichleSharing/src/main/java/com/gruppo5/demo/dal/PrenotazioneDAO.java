package com.gruppo5.demo.dal;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gruppo5.demo.entities.Prenotazione;

public interface PrenotazioneDAO extends JpaRepository<Prenotazione, Integer>{
	
	List<Prenotazione> findByIdUtenteAndStato(int idUtente, boolean stato);
	
	Prenotazione findByIdUtenteAndIdVeicoloAndStato(int idUtente, int idVeicolo, boolean stato);
	
}
