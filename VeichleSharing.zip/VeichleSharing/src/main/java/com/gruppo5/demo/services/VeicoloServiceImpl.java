package com.gruppo5.demo.services;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.gruppo5.demo.config.CustomProperties;
import com.gruppo5.demo.dal.VeicoloDAO;
import com.gruppo5.demo.entities.Veicolo;
import com.gruppo5.demo.util.FileVeichleUtil;

@Service
public class VeicoloServiceImpl implements VeicoloService {

	@Autowired
	private VeicoloDAO repo;
	
	public Veicolo saveOne(Veicolo v, MultipartFile multipartFile) {
		
		
		//nome del file immagine
		String fileName = StringUtils.cleanPath("veicoloImg.jpg");
		
		//setto nome file prima di salvare il veicolo
		v.setNameImg(fileName);
		
		//salvo il veicolo
		Veicolo veicoloSalvato = repo.save(v);
		
		String uploadDir = CustomProperties.basepath + "/" + v.getId();
		
		try {
			FileVeichleUtil.saveFile(uploadDir, fileName, multipartFile);
		}
		catch(IOException e) {
			
			e.printStackTrace();
		}
		
		return veicoloSalvato;	
		
	}
	
	@Override
	public Veicolo saveOne(Veicolo v) {
		return repo.save(v);
	}

	@Override
	public Veicolo getVeicoloById(int id) {
		
		return this.repo.findById(id).get();
	}

	@Override
	public List<Veicolo> findAll() {
		
		return this.repo.findAll();
	}

	@Override
	public List<Veicolo> getAllByTipologia(String tipologia) {
		
		return this.repo.findByTipologia(tipologia);
	}

	@Override
	public void deleteVeicoloById(int id) {
		
		this.repo.deleteById(id);
	}
	
	@Override
	public List<Veicolo> getAllByDisponibilita(boolean disponibilita){
		return this.repo.findByDisponibilita(disponibilita);
	}

	@Override
	public Veicolo getDisponibilitaById(boolean disponibilita) {
		
		return this.repo.findDisponibilitaById(disponibilita);
	}

	@Override
	public void toggleDisponibilita(Veicolo veicolo) {
		
		if(veicolo.isDisponibilita() == true) {
			veicolo.setDisponibilita(false);
			repo.save(veicolo);
		}
		else {
			veicolo.setDisponibilita(true);
			repo.save(veicolo);
		}
		
		
	}

}
