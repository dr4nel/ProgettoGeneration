package com.gruppo5.demo.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.gruppo5.demo.dal.PrenotazioneDAO;
import com.gruppo5.demo.entities.Prenotazione;
import com.gruppo5.demo.entities.Utente;
import com.gruppo5.demo.entities.Veicolo;
import com.gruppo5.demo.services.PrenotazioneService;
import com.gruppo5.demo.services.VeicoloService;


@Controller
@RequestMapping("/pannello-user")
@SessionAttributes("utente")
public class AreaVeicoloPersonale {

	@Autowired
	VeicoloService vs;
	
	@Autowired
	PrenotazioneService ps;
	
	@Autowired
	PrenotazioneDAO repoPrenotaz;
	
	
	@GetMapping
	public String getPannelloUser(Utente utente, Model model) {
		List<Prenotazione> prenotazioni= repoPrenotaz.findByIdUtenteAndStato(utente.getId(), true);
		ArrayList<Veicolo> listaVeicoli = new ArrayList<Veicolo>();
		for (Prenotazione prenotazione : prenotazioni) {
			listaVeicoli.add(vs.getVeicoloById(prenotazione.getIdVeicolo()));
		}
		model.addAttribute("findAll", listaVeicoli);
		return "pannello-user";
	}
	
	@GetMapping("/termina-prenotazione/{idveicolo}")
	public String terminaPrenotazione(@PathVariable("idveicolo") int idveicolo, Model model, Utente utente) {
		
		//cerco veicolo
		Veicolo veicolo = vs.getVeicoloById(idveicolo);
		
		if(veicolo == null)
			return "redirect:/pannello-user" ;
		
		//cambio lo stato			
		ps.terminaPrenotazione(utente.getId(), idveicolo);
		vs.toggleDisponibilita(veicolo);	

		
		return "redirect:/pannello-user";
		
	}
}
