package com.gruppo5.demo.dal;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gruppo5.demo.entities.Veicolo;

public interface VeicoloDAO extends JpaRepository<Veicolo, Integer> {

	List<Veicolo> findByTipologia(String tipologia);
	
	List<Veicolo> findByDisponibilita(boolean disponibilita);
	
	Veicolo findDisponibilitaById(boolean disponibilita);
}
