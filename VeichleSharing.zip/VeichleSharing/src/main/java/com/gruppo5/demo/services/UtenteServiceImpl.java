package com.gruppo5.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gruppo5.demo.dal.UtenteDAO;
import com.gruppo5.demo.entities.Utente;

@Service
public class UtenteServiceImpl implements UtenteService {

	@Autowired
	private UtenteDAO repo;
	
	@Override
	public Utente saveOne(Utente u) {
		
		return repo.save(u);
	}

	@Override
	public Utente getUtenteById(int id) {
		
		return repo.findById(id).get();
	}

	@Override
	public List<Utente> findAll() {
		
		return repo.findAll();
	}

	@Override
	public List<Utente> getAllByTipo(String tipo) {
		
		return repo.findByTipo(tipo);
	}

	@Override
	public void deleteUtenteById(int id) {
		
		repo.deleteById(id);

	}

	@Override
	public Utente findByEmail(String email) {
		
		return repo.findByEmail(email);
	}
}
