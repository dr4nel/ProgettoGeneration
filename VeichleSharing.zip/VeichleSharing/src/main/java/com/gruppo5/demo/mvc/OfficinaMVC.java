package com.gruppo5.demo.mvc;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.gruppo5.demo.entities.Veicolo;
import com.gruppo5.demo.services.VeicoloService;

@Controller
@RequestMapping("/lista-veicoli-mvc")
@SessionAttributes("utente")
public class OfficinaMVC {
	
	@Autowired
	VeicoloService vs;

	
	//Tutti i veicoli
	@GetMapping//rotta /veicoliAdmin
	public String findAll(Model model) {
		model.addAttribute("findAll", vs.findAll());
		
		return "lista-veicoli-mvc";
	}
	
	//Aggiorno un veicolo
	@GetMapping("/{idveicolo}") //rotta /veicoloAdmin/{idveicolo}
	public String updForm(@PathVariable("idveicolo") int idveicolo, Model model) {
		//cerco il veicolo da modificare
		Veicolo veicolo = vs.getVeicoloById(idveicolo);
		
		//controllo se esiste
		if(veicolo == null)
			return "redirect:/lista-veicoli-mvc";
		
		//lo aggiungo al model
		model.addAttribute("veicolo", veicolo);
		
		return "veicolo-form";
	}
	
	//Salvo il nuovo veicolo
	@PostMapping("/save")
	public String saveVeicolo(Veicolo v, @RequestParam("image") MultipartFile multipartFile, Model model) {
		
		//creo un veicolo vuoto da restituire con l'id
		Veicolo veicoloSaved = new Veicolo();
		
		//controllo se è stata caricata un'immagine
		if(multipartFile == null || multipartFile.isEmpty())
			//salvo comunque un veicolo
			veicoloSaved = vs.saveOne(v);
		else
			//salvo veicolo e immagine nella cartella
			veicoloSaved = vs.saveOne(v, multipartFile);
		
		model.addAttribute("veicolo", veicoloSaved);
		
		//mi riporta alla pagine iniziale
		return "redirect:/lista-veicoli-mvc";
	}
	
	//Creo un nuovo veicolo
	@GetMapping("/addform")
	public String addForm(Model model) {
		//aggiugno un veicolo vuoto
		//lo collego ai campi del form
		model.addAttribute("veicolo", new Veicolo());
		
		return "/veicolo-form";
	}
	
	//Cancello un veicolo
	@GetMapping("/delete/{idveicolo}")
	public String delVeicolo(@PathVariable("idveicolo") int idveicolo) {
		
		//cerco il veicolo
		Veicolo veicolo = vs.getVeicoloById(idveicolo);
		
		//controllo l'id
		if(veicolo == null)
			return "redirect:/lista-veicoli-mvc";
		
		//cancello il veicolo
		vs.deleteVeicoloById(idveicolo);
		
		return "redirect:/lista-veicoli-mvc";
	}
	
	


	

		
}
