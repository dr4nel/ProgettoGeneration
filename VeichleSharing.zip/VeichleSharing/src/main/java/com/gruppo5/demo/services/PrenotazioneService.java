package com.gruppo5.demo.services;

public interface PrenotazioneService {

	void nuovaPrenotazione(int idUtente, int idVeicolo);
	
	void terminaPrenotazione(int idUtente, int idVeicolo);
	
	
}
