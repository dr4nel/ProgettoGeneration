package com.gruppo5.demo.mvc;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.gruppo5.demo.entities.Utente;
import com.gruppo5.demo.entities.Veicolo;
import com.gruppo5.demo.services.PrenotazioneService;
import com.gruppo5.demo.services.VeicoloService;

@Controller
@RequestMapping("/vista-veicolo")
@SessionAttributes("utente")
public class VistaVeicolo {
	@Autowired
	VeicoloService vs;
	
	@Autowired
	PrenotazioneService ps;
	
	
	@GetMapping("/{idveicolo}")
	public String vistaVeicolo(@PathVariable("idveicolo") int idVeicolo, Model model, Utente utente) {
		model.addAttribute("veicolo", vs.getVeicoloById(idVeicolo));
		
		return "vista-veicolo";
	}
	
	
	//metodo prenotazione
	@GetMapping("/prenota-veicolo/{idveicolo}")
	public String prenotaVeicolo(@PathVariable("idveicolo") int idveicolo, Model model, Utente utente) {
		
		//cerco veicolo
		Veicolo veicolo = vs.getVeicoloById(idveicolo);
		
		if(veicolo == null || veicolo.isDisponibilita() == false)
			return "redirect:/";
		
		//cambio lo stato			
		ps.nuovaPrenotazione(utente.getId(), idveicolo);
		vs.toggleDisponibilita(veicolo);	

		
		//return "redirect:/vista-veicolo/" + idVeicolo;
		return "redirect:/";
		
	}

	
	
	
	
}
