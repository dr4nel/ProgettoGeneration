package com.gruppo5.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gruppo5Application {

	public static void main(String[] args) {
		SpringApplication.run(Gruppo5Application.class, args);
	}

}
