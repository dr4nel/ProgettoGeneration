package com.gruppo5.demo.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class CustomProperties {

	
	//creo percorso in cui creare la cartella per le immagini
	public static String basepath = "veicoloimg";
	
	//percorso per l'immagine di dafault
	public static String defaultImg = "img/veicoloDefault.png";
	
	
	
	
	
	
}
