package com.gruppo5.demo.il;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gruppo5.demo.entities.Utente;
import com.gruppo5.demo.entities.Veicolo;
import com.gruppo5.demo.services.UtenteService;
import com.gruppo5.demo.services.VeicoloService;

@RestController
@RequestMapping("api")
public class OfficinaREST {
	
	@Autowired
	private VeicoloService veicoloService;
	@Autowired
	private UtenteService utenteService;
	
	//VEICOLO
	
	@GetMapping("/veicoli")
	@CrossOrigin
	public List<Veicolo> getVeicoli(){
		return veicoloService.findAll();
	}
	
	@GetMapping("/veicoli/{id}")
	public Veicolo getVeicolo(@PathVariable int id) {
		return veicoloService.getVeicoloById(id);
	}
	
	@PostMapping(value = "", consumes = "application/json")
	public void addVeicolo(@RequestBody Veicolo v) {
		veicoloService.saveOne(v);
	}
	
	@PutMapping(value = "", consumes = "application/json")
	public void modVeicolo(@RequestBody Veicolo v) {
		veicoloService.saveOne(v);
	}
	
	@DeleteMapping("/veicolo/{id}")
	public void delVeicolo(@PathVariable int id) {
		veicoloService.deleteVeicoloById(id);
	}	
	
	@GetMapping("/veicolo/{true}")
	public List<Veicolo> getDisponibili(@PathVariable boolean disponibilita){
		return veicoloService.getAllByDisponibilita(disponibilita);
	}
	
	
	//UTENTE
	
	@GetMapping("/utenti")
	@CrossOrigin
	public List<Utente> getUtenti(){
		return utenteService.findAll();
	}
}
