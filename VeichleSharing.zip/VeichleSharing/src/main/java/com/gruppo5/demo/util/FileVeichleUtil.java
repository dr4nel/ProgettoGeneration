package com.gruppo5.demo.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.web.multipart.MultipartFile;

import com.gruppo5.demo.config.CustomProperties;
import com.gruppo5.demo.entities.Veicolo;

public class FileVeichleUtil {

	public static void saveFile(String uploadDir, String nameImg, MultipartFile multipartFile) throws IOException{
		
		
		//converte il perxorso stringa in path
		Path uploadPath =  Paths.get(uploadDir);
		
		if(!Files.exists(uploadPath)) {
			
			//crea una cartella se non esiste nel percorso
			Files.createDirectories(uploadPath);
		}
		
		try(InputStream inputStream = multipartFile.getInputStream()){
			
			Path filePath = uploadPath.resolve(nameImg);
			
			Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
		}
		catch(IOException ioe){
			throw new IOException("Non è possibile salvare l'immagine: " + nameImg, ioe);
		}	
	}
	
	
	public static void deleteDir(Veicolo trovato) {
		try {
			String dir = CustomProperties.basepath + "/" + trovato.getId();
			
			if(Files.exists(Paths.get(dir))) {
				
				FileUtils.deleteDirectory(new File(dir));
			}
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
}
