package com.gruppo5.demo.services;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.gruppo5.demo.entities.Veicolo;

public interface VeicoloService {

	Veicolo saveOne(Veicolo v, MultipartFile multipartFile); // C: aggiungo un veicolo al db || U: aggiorno un veicolo del db
	
	Veicolo saveOne(Veicolo v);
	
	Veicolo getVeicoloById(int id); //R: passo un id e mi ritorna un veicolo con l'id corrispondente
	
	List<Veicolo> findAll(); //R: ritorna tutti i veicoli
	
	List<Veicolo> getAllByTipologia(String tipologia); //R: ritorna la lista della tipologia scelta
	
	void deleteVeicoloById(int id); //D: cancello un veicolo tramite id
	
	List<Veicolo> getAllByDisponibilita(boolean disponibilita);
	
	Veicolo getDisponibilitaById(boolean disponibilita);
	
	void toggleDisponibilita(Veicolo veicolo);

	
	
	

}
