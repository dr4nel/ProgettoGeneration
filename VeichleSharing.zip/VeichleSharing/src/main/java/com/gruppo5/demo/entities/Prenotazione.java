package com.gruppo5.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "prenotazione")
public class Prenotazione {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private int idUtente;
	
	private int idVeicolo;
	
	private boolean stato = true; //true in corso - false terminata
	
	public Prenotazione() {
		// TODO Auto-generated constructor stub
	}

	public Prenotazione(int idUtente, int idVeicolo, boolean stato) {
		this.idUtente = idUtente;
		this.idVeicolo = idVeicolo;
		this.stato = stato;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(int idUtente) {
		this.idUtente = idUtente;
	}

	public int getIdVeicolo() {
		return idVeicolo;
	}

	public void setIdVeicolo(int idVeicolo) {
		this.idVeicolo = idVeicolo;
	}

	public boolean isStato() {
		return stato;
	}

	public void setStato(boolean stato) {
		this.stato = stato;
	}

	
	
	
	
}
