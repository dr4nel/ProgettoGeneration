package com.gruppo5.demo.entities;

import java.sql.Date;
import java.util.Calendar;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gruppo5.demo.config.CustomProperties;

@Entity
@Table(name = "veicoli")
public class Veicolo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String tipologia; //auto, monopattino, scooter, bicicletta
	private String alimentazione; //diesel, ibrida, benzina, elettrica
	private String descrizione; //modello, colore, cilindrata
	private boolean disponibilita;
	private Date data = new Date(Calendar.getInstance().getTime().getTime());
	private String nameImg;
	private String posizione;
	private int idCreatore;
	
	public Veicolo() {
		
	}

	public Veicolo(int id, String tipologia, String alimentazione, String descrizione, boolean disponibilita, Date data,
			String nameImg, String posizione, int idCreatore) {
		this.id = id;
		this.tipologia = tipologia;
		this.alimentazione = alimentazione;
		this.descrizione = descrizione;
		this.disponibilita = disponibilita;
		this.data = data;
		this.nameImg = nameImg;
		this.posizione = posizione;
		this.idCreatore = idCreatore;
	}

	//metodo che genera l'url
	public String getUrl() {
		
		//controllo se esiste l'immagine
		if(nameImg == null || nameImg.equals(""))
			
			//se non esiste ritorno l'immagine di default
			return "/" + CustomProperties.defaultImg;
		
		//se esiste ritorno l'immagine con l'id
		return "/" + CustomProperties.basepath + "/" + id + "/" + nameImg;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTipologia() {
		return tipologia;
	}

	public void setTipologia(String tipologia) {
		this.tipologia = tipologia;
	}

	public String getAlimentazione() {
		return alimentazione;
	}

	public void setAlimentazione(String alimentazione) {
		this.alimentazione = alimentazione;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public boolean isDisponibilita() {
		return disponibilita;
	}

	public void setDisponibilita(boolean disponibilita) {
		this.disponibilita = disponibilita;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getNameImg() {
		return nameImg;
	}

	public void setNameImg(String nameImg) {
		this.nameImg = nameImg;
	}

	public String getPosizione() {
		return posizione;
	}

	public void setPosizione(String posizione) {
		this.posizione = posizione;
	}

	public int getIdCreatore() {
		return idCreatore;
	}

	public void setIdCreatore(int idCreatore) {
		this.idCreatore = idCreatore;
	}
		
}
	
	
	
	