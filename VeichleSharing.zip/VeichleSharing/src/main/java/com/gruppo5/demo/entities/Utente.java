package com.gruppo5.demo.entities;

import java.sql.Date;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "utenti")
public class Utente{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String nome;
	private String cognome;
	private Date dataNascita;
	
	@Column(unique=true)
	private String email;
	
	private String password;
	private String tipo; //ruolo di default utente classico - A utente admin
	private Date dataIscrizione = new Date(Calendar.getInstance().getTime().getTime());
	private String firma;
	private Date ultimaModifica = new Date(Calendar.getInstance().getTime().getTime());
	
	
	//COSTRUTTORI//
	
	//Default
	public Utente() {
		
	}
	
	
	public Utente(int id, String nome, String cognome, Date dataNascita, String email, String password, String tipo,
			Date dataIscrizione, String firma, Date ultimaModifica) {
		super();
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.dataNascita = dataNascita;
		this.email = email;
		this.password = password;
		this.tipo = tipo;
		this.dataIscrizione = dataIscrizione;
		this.firma = firma;
		this.ultimaModifica = ultimaModifica;
	}

	
	//GETTER AND SETTER
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public Date getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(Date dataNascita) {
		this.dataNascita = dataNascita;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Date getDataIscrizione() {
		return dataIscrizione;
	}

	public void setDataIscrizione(Date dataIscrizione) {
		this.dataIscrizione = dataIscrizione;
	}

	public String getFirma() {
		return firma;
	}

	public void setFirma(String firma) {
		this.firma = firma;
	}

	public Date getUltimaModifica() {
		return ultimaModifica;
	}

	public void setUltimaModifica(Date ultimaModifica) {
		this.ultimaModifica = ultimaModifica;
	}
	
	//METODI AGGIUNTIVI
	

}
