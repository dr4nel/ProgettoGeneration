package com.gruppo5.demo.services;

import java.util.List;

import com.gruppo5.demo.entities.Utente;

public interface UtenteService {
	
	Utente saveOne(Utente u); // C: aggiungo un Utente al db || U: aggiorna un Utente
	
	Utente getUtenteById(int id); //R: passo un id e mi ritorna un Utente con l'id corrispondente
	
	List<Utente> findAll(); //R: ritorna tutti i utenti
	
	List<Utente> getAllByTipo(String tipo); //R: ritorna la lista della tipologia scelta
	
	void deleteUtenteById(int id); //D: cancello un Utente tramite id
	
	Utente findByEmail(String email);

}
