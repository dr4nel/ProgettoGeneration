package com.gruppo5.demo.dal;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gruppo5.demo.entities.Utente;

public interface UtenteDAO extends JpaRepository<Utente, Integer> {
	
	List<Utente> findByTipo(String tipo);
	Utente findByEmail(String email);
	
}
