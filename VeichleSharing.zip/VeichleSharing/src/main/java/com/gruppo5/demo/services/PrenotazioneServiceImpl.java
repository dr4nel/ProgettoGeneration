package com.gruppo5.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gruppo5.demo.dal.PrenotazioneDAO;
import com.gruppo5.demo.entities.Prenotazione;

@Service
public class PrenotazioneServiceImpl implements PrenotazioneService {

	@Autowired
	private PrenotazioneDAO repo;
	
	@Override
	public void nuovaPrenotazione(int idUtente, int idVeicolo) {
		
		Prenotazione p = new Prenotazione(idUtente, idVeicolo, true);
		repo.save(p);

	}

	@Override
	public void terminaPrenotazione(int idUtente, int idVeicolo) {
		
		Prenotazione p = repo.findByIdUtenteAndIdVeicoloAndStato(idUtente, idVeicolo, true);
		p.setStato(false);
		repo.save(p);
	}


}
