package com.gruppo5.demo.mvc;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.gruppo5.demo.dal.PrenotazioneDAO;
import com.gruppo5.demo.entities.Utente;
import com.gruppo5.demo.services.UtenteService;
import com.gruppo5.demo.services.VeicoloService;

@Controller
@RequestMapping("/")
@SessionAttributes("utente")
public class ControllerPagine {
	
	@Autowired
	UtenteService us;
	
	@Autowired
	VeicoloService vs;
	
	@Autowired
	PrenotazioneDAO repoPrenotaz;
	
	@GetMapping("chi-siamo")
	public String getAbout(Utente utente, Model model) {
		return "chi-siamo";
	}
	
	@GetMapping("contatti")
	public String getContatti(Utente utente, Model model) {
		return "contatti";
	}
	
	@GetMapping("faq")
	public String getFaq(Utente utente, Model model) {
		return "faq";
	}
	
	@GetMapping("forgotpassword")
	public String getForgot(Utente utente, Model model) {
		return "forgotpassword";
	}
	
	@GetMapping
	public String getIndex(Utente utente, Model model) {
		return "index";
	}
	
	@GetMapping("login")
	public String getLogin(Utente utente, Model model) {
		return "login";
	}
	
	@PostMapping("login-utente")
	public String postLogin(Utente utente, Model model ) {
		
		Utente utenteIscritto = us.findByEmail(utente.getEmail());
		
		if(utenteIscritto != null && utenteIscritto.getPassword().equals(utente.getPassword())) {
			model.addAttribute("utente", utenteIscritto);
			return "redirect:/";
		}
		else{
			model.addAttribute("messaggio", "Login errato, riprova");
			utente.setEmail(null);
			utente.setPassword(null);
			return "login";
			}
	}
	
	@GetMapping("/logout")
	public String logout(SessionStatus status, Model model) {//2
		
		// 3) cancello la sessione, e con esso l'utente salvato
		
		//3
		status.setComplete();
		
		return "redirect:/";
	}
	
	@GetMapping("/logout-chi-siamo")
	public String logoutChiSiamo(SessionStatus status, Model model) {//2
		
		// 3) cancello la sessione, e con esso l'utente salvato
		
		//3
		status.setComplete();
		
		return "redirect:/chi-siamo";
	}
	
	@GetMapping("pannello")
	public String getPannello(Utente utente, Model model) {
		return "pannello";
	}
	
	@GetMapping("recuperoEmail")
	public String getRecuperoEmail(Utente utente, Model model) {
		return "recuperoEmail";
	}
	
	@GetMapping("termini")
	public String getTermini(Utente utente, Model model) {
		return "termini";
	}
	

	
	
	
	
	
}
