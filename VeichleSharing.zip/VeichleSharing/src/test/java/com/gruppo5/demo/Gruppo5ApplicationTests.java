package com.gruppo5.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.gruppo5.demo.entities.Utente;
import com.gruppo5.demo.entities.Veicolo;
import com.gruppo5.demo.services.UtenteService;
import com.gruppo5.demo.services.VeicoloService;

@SpringBootTest
class Gruppo5ApplicationTests {

	@Autowired
	VeicoloService vs;
	
	@Autowired 
	UtenteService us;
	
	@Test
	void contextLoads() {
		
		
		Veicolo v1 = new Veicolo();
		v1.setTipologia("Automobile");
		v1.setDescrizione("Fiat Panda");
		v1.setAlimentazione("Ibrida");
		v1.setDisponibilita(true);
		v1.setData(null);
		v1.setIdCreatore(0);
		
		Veicolo v2 = new Veicolo();
		v2.setTipologia("Scooter");
		v2.setDescrizione("Vespa");
		v2.setAlimentazione("diesel");
		v2.setDisponibilita(true);
		v2.setData(null);
		v2.setIdCreatore(1);
		
		vs.saveOne(v1);
		
		vs.saveOne(v2);
		
		Utente u1 = new Utente();
		
		u1.setNome("Andrea");
		u1.setUltimaModifica(null);
		u1.setCognome("Loi");
		
		us.saveOne(u1);
	}
}